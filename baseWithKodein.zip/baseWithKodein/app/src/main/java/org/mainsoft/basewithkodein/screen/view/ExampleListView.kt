package org.mainsoft.basewithkodein.screen.view

import org.mainsoft.basewithkodein.net.response.CountryResponse
import org.mainsoft.basewithkodein.screen.view.base.BaseListView

interface ExampleListView : BaseListView<CountryResponse>