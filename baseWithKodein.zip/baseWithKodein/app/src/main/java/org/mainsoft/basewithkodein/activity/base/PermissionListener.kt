package org.mainsoft.basewithkodein.activity.base

interface PermissionListener {

    fun onComplete()

    fun onError()
}