package org.mainsoft.basewithkodein.base

interface OnItemLongClickListener : OnItemClickListener {
    fun onItemLongClick(position: Int)
}
