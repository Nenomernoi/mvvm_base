package org.mainsoft.basewithkodein.screen.view.base

interface BaseNoTitlePageView : BaseView {
    fun openPage(page: Int)
}
