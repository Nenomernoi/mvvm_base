package org.mainsoft.basewithkodein.base

interface OnItemClickListener {
    fun onItemClick(position: Int)
}
