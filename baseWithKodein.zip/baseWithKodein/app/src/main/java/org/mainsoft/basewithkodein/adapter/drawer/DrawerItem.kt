package org.mainsoft.basewithkodein.adapter.drawer

class DrawerItem(var id: Int, var resName: Int, var imgResID: Int, var isAuth: Boolean)