package org.mainsoft.basewithkodein.screen.presenter.base

interface Presenter {
    fun onStop()
}
