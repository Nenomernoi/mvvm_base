package org.mainsoft.basewithkodein.screen.view

import org.mainsoft.basewithkodein.screen.view.base.BasePageView

interface ExamplePageView : BasePageView<String>